RPAL Interpreter
COP5555 Project 2 Spring 2013
Ryan Roden-Corrent
4869-9998

To make:
make
To test:
make test
(This assumes user has rpal in the current directory and the directory ~/rpal/tests contains the test files)
To run:
./p2 FILENAME

Interpreter freezes on tiny and tiny.1, please press Ctrl-C (SIGINTERRUPT) to skip these tests.
Interpreter should fail no more than 9 tests.
